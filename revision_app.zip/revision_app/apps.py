from django.apps import AppConfig


class RevisionAppConfig(AppConfig):
    name = 'revision_app'
